//
//  Main.hpp
//  C++ Program
//
//  Created by Filip Nilsson on 2016-07-15.
//  Copyright © 2016 Exyza. All rights reserved.
//

#ifndef Main_hpp
#define Main_hpp

#include <stdio.h>

#endif /* Main_hpp */
