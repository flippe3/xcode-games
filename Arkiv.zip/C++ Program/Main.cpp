//
//  Main.cpp
//  C++ Program
//
//  Created by Filip Nilsson on 2016-07-15.
//  Copyright © 2016 Exyza. All rights reserved.
//
#include "Main.hpp"
#include <iostream>

using namespace std;

int main(){
    cout << "Hello World" << endl;
    
    return 0;

}
