//
//  main.cpp
//  Console c++
//
//  Created by Filip Nilsson on 2016-07-15.
//  Copyright © 2016 Exyza. All rights reserved.
//

#include <iostream>

using namespace std;

int main() {
    const int MAX_ROWS = 3;
    const int MAX_COLS = 4;
    
    int MyInts[MAX_ROWS][MAX_COLS] = {{0,1,2,3},{0,1,2,3},{0,1,2,3} };
    
    for(int Row = 0; Row < MAX_ROWS; ++Row){
    for (int Column = 0; Column < MAX_COLS; ++Column){
        cout << "Integer[" << Row << "][" << Column \
        << "] = " << MyInts[Row][Column] << endl;
    
    }
    }
    return 0;
}
