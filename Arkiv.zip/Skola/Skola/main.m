//
//  main.m
//  Skola
//
//  Created by Filip Nilsson on 2016-08-23.
//  Copyright © 2016 Exyza. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    return 0;
}
