//
//  ViewController.swift
//  Animation
//
//  Created by Filip Nilsson on 2016-06-01.
//  Copyright © 2016 Exyza. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var myImageView: UIImageView!
    var myImages = [UIImage]()
    
    @IBAction func startKey(_ sender: AnyObject) {
        myImageView.startAnimating()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        //bild.addGestureRecognizer(UIPanGestureRecognizer(target: self,action: self.m)
        for i in 1...5{
            myImages.append(UIImage(named: "Bronze Animation\(i)")!)
            
        }
        myImageView.animationImages = myImages
        // Do any additional setup after loading the view, typically from a nib.
    }
    
}

