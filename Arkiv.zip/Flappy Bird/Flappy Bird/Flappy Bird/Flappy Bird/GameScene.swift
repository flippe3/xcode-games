//
//  GameScene.swift
//  Flappy Bird
//
//  Created by Filip Nilsson on 2016-05-30.
//  Copyright (c) 2016 Exyza. All rights reserved.
//

import SpriteKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    

    struct physicsCatagory {
        static let Ghost : UInt32 = 0x1 << 1
        static let Ground : UInt32 = 0x1 << 2
        static let Wall : UInt32 = 0x1 << 3
        static let Score : UInt32 = 0x1 << 4
    }
    
    
    var Ground = SKSpriteNode()
    var Ghost = SKSpriteNode()
    var wallPair = SKNode()
    var moveAndRemove = SKAction()
    var score = Int()
    let scoreLbl = SKLabelNode()
    
    var died = Bool()
    var restartBTN = SKSpriteNode()
    
    var gameStarted = Bool()
    
    func restartScene(){
        self.removeAllChildren()
        self.removeAllActions()
        died = false
        gameStarted = false
        score = 0
        createScene()
    }
    
    func createScene(){
        /* Setup your scene here */
        
        
        self.physicsWorld.contactDelegate = self
        
        scoreLbl.position = CGPoint(x: self.frame.width / 2, y: self.frame.height / 2 + self.frame.height / 2.5)
        scoreLbl.text = "\(score)"
        scoreLbl.zPosition = 5
        self.addChild(scoreLbl)
        
        
        Ground = SKSpriteNode(imageNamed: "ground-1")
        Ground.size = CGSize(width: 460, height: 50)
        Ground.position = CGPoint(x: self.frame.width / 2, y: 0 + Ground.frame.height / 2)
        
        Ground.physicsBody = SKPhysicsBody(rectangleOfSize: Ground.size)
        Ground.physicsBody?.categoryBitMask = physicsCatagory.Ground
        Ground.physicsBody?.collisionBitMask = physicsCatagory.Ghost
        Ground.physicsBody?.contactTestBitMask = physicsCatagory.Ghost
        Ground.physicsBody?.affectedByGravity = false
        Ground.physicsBody?.dynamic = false
        
        Ground.zPosition = 3
        
        self.addChild(Ground)
        
        
        Ghost = SKSpriteNode(imageNamed: "flappy-bird")
        Ghost.size = CGSize(width: 75, height: 55)
        Ghost.position = CGPoint(x: self.frame.width / 2, y: self.frame.height / 2)
        Ghost.physicsBody = SKPhysicsBody(circleOfRadius: Ghost.frame.height / 2)
        Ghost.physicsBody?.categoryBitMask = physicsCatagory.Ghost
        Ghost.physicsBody?.collisionBitMask = physicsCatagory.Ground | physicsCatagory.Wall
        Ghost.physicsBody?.contactTestBitMask = physicsCatagory.Ground | physicsCatagory.Wall | physicsCatagory.Score
        Ghost.physicsBody?.dynamic = true
        Ghost.zPosition = 2
        
        self.addChild(Ghost)
    
    }
    override func didMoveToView(view: SKView) {
        createScene()
        
    }
    func createBTN(){
        restartBTN = SKSpriteNode(imageNamed: "RestartBtn")
        restartBTN.size = CGSize(width: 200, height: 100)
        restartBTN.position = CGPoint(x: self.frame.width / 2, y:self.frame.height / 2)
        restartBTN.zPosition = 6
        self.addChild(restartBTN)
    }
    func didBeginContact(contact: SKPhysicsContact) {
        let firstBody = contact.bodyA
        let secondBody = contact.bodyB
        
        if firstBody.categoryBitMask == physicsCatagory.Score && secondBody.categoryBitMask == physicsCatagory.Ghost || firstBody.categoryBitMask == physicsCatagory.Ghost && secondBody.categoryBitMask == physicsCatagory.Score{
            score = score + 1
            print(score)
            scoreLbl.text = "\(score)"
            
        }
        else if firstBody.categoryBitMask == physicsCatagory.Ghost && secondBody.categoryBitMask == physicsCatagory.Wall || firstBody.categoryBitMask == physicsCatagory.Wall && secondBody.categoryBitMask == physicsCatagory.Ghost
        {
            createBTN()
        
        }
        if died == false{
            died = true
            createBTN()
        }
        else if firstBody.categoryBitMask == physicsCatagory.Ghost && secondBody.categoryBitMask == physicsCatagory.Ground || firstBody.categoryBitMask == physicsCatagory.Ground && secondBody.categoryBitMask == physicsCatagory.Ghost
        {
            createBTN()
            
        }
        if died == false{
            died = true
            createBTN()
        }
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        if gameStarted == false{
            
            gameStarted = true
            
            Ghost.physicsBody?.affectedByGravity = true
            let spawn = SKAction.runBlock({
                ()in
                self.createWalls()
                
            })
            let delay = SKAction.waitForDuration(2.0)
            let spawnDelay = SKAction.sequence([spawn,delay])
            let spawnDelayForever = SKAction.repeatActionForever(spawnDelay)
            self.runAction(spawnDelayForever)
            
            
            let distance = CGFloat(self.frame.width + wallPair.frame.width)
            let movePipes = SKAction.moveByX(-distance, y: 0, duration: NSTimeInterval(0.01 * distance))
            let removePipes = SKAction.removeFromParent()
            moveAndRemove = SKAction.sequence([movePipes,removePipes])
            Ghost.physicsBody?.velocity = CGVectorMake(0, 0)
            Ghost.physicsBody?.applyImpulse(CGVectorMake(0, 65))
        
        }
        else{
            
            if died == true{
                
            
            }
            else{
                Ghost.physicsBody?.velocity = CGVectorMake(0, 0)
                Ghost.physicsBody?.applyImpulse(CGVectorMake(0, 65))
            }
            
        }
        
        for touch in touches{
            let location = touch.locationInNode(self)
            if died == true{
                if restartBTN.containsPoint(location){
                restartScene()
                }
            }
        
        
    }
    }
    func createWalls(){
        
        let scoreNode = SKSpriteNode()
        scoreNode.size = CGSize(width: 1, height: 200)
        scoreNode.position = CGPoint(x:  self.frame.width, y: self.frame.height / 2)
        scoreNode.physicsBody = SKPhysicsBody(rectangleOfSize: scoreNode.size)
        scoreNode.physicsBody?.affectedByGravity = false
        scoreNode.physicsBody?.dynamic = false
        scoreNode.physicsBody?.categoryBitMask = physicsCatagory.Score
        scoreNode.physicsBody?.collisionBitMask = 0
        scoreNode.physicsBody?.contactTestBitMask = physicsCatagory.Ghost
        
        wallPair = SKNode()
        
        let topWall = SKSpriteNode(imageNamed: "tube1")
        let botWall = SKSpriteNode(imageNamed: "tube1")
        topWall.position = CGPoint(x: self.frame.width,y: self.frame.height / 2 + 350)
        botWall.position = CGPoint(x: self.frame.width,y: self.frame.height / 2 - 350)
        topWall.size = CGSize(width: 75, height: 500)
        botWall.size = CGSize(width: 75, height: 500)
        
        topWall.physicsBody = SKPhysicsBody(rectangleOfSize: topWall.size)
        topWall.physicsBody?.categoryBitMask = physicsCatagory.Wall
        topWall.physicsBody?.collisionBitMask = physicsCatagory.Ghost
        topWall.physicsBody?.contactTestBitMask = physicsCatagory.Ghost
        topWall.physicsBody?.affectedByGravity = false
        topWall.physicsBody?.dynamic = false
        
        botWall.physicsBody = SKPhysicsBody(rectangleOfSize: botWall.size)
        botWall.physicsBody?.categoryBitMask = physicsCatagory.Wall
        botWall.physicsBody?.collisionBitMask = physicsCatagory.Ghost
        botWall.physicsBody?.contactTestBitMask = physicsCatagory.Ghost
        botWall.physicsBody?.affectedByGravity = false
        botWall.physicsBody?.dynamic = false
        
        botWall.zRotation = CGFloat(M_PI)
        
        wallPair.addChild(topWall)
        wallPair.addChild(botWall)
        
        wallPair.zPosition = 1
        
        let randomPosition = CGFloat.random(min: -200, max: 200)
        wallPair.position.y = wallPair.position.y + randomPosition
        wallPair.addChild(scoreNode)
        
        wallPair.runAction(moveAndRemove)
        self.addChild(wallPair)
        
        
        
    }
    
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
    }
}

