//
//  GameScene.swift
//  GameScene For Watch Extension
//
//  Created by Filip Nilsson on 2016-06-19.
//  Copyright © 2016 Exyza. All rights reserved.
//

import SpriteKit

struct PhysicsCatagory {
    static let Ground : UInt32 = 0x1 << 1
    static let Character : UInt32 = 0x1 << 2
    static let Wall : UInt32 = 0x1 << 3
    static let Score : UInt32 = 0x1 << 4
}

class GameScene: SKScene,SKPhysicsContactDelegate {
    
    var background1 = SKSpriteNode(imageNamed: "Wallpaper")
    var character = SKSpriteNode(imageNamed: "Character")
    var ground = SKSpriteNode(imageNamed: "ground")
    var x = 0
    var y = 0
    var right = false
    var left = false
    
    func createScene(){
        background1.anchorPoint = CGPoint.zero
        background1.position = CGPoint(x: -160,y: -179)
        background1.size = CGSize(width: 320, height: 380)
        background1.zPosition = -15
        self.addChild(background1)
        
        ground = SKSpriteNode(imageNamed: "ground")
        ground.size = CGSize(width: 320, height: 55)
        ground.position = CGPoint(x: 0, y: -70)
        ground.physicsBody = SKPhysicsBody(rectangleOf: ground.size)
        ground.physicsBody?.categoryBitMask = PhysicsCatagory.Ground
        ground.physicsBody?.collisionBitMask = PhysicsCatagory.Character
        ground.physicsBody?.contactTestBitMask = PhysicsCatagory.Character
        ground.physicsBody?.affectedByGravity = false
        ground.physicsBody?.isDynamic = false
        ground.zPosition = 1
        self.addChild(ground)
        
        character.position = CGPoint(x: 0, y:  70)
        character.size = CGSize(width: 60, height: 60)
        character.physicsBody = SKPhysicsBody(rectangleOf: character.size)
        character.physicsBody?.categoryBitMask = PhysicsCatagory.Character
        character.physicsBody?.collisionBitMask = PhysicsCatagory.Ground
        character.physicsBody?.contactTestBitMask = PhysicsCatagory.Ground
        character.physicsBody?.affectedByGravity = true
        character.physicsBody?.isDynamic = true
        character.zPosition = 2
        self.addChild(character)
        
    }
    override func sceneDidLoad() {
        createScene()
        
    }
    func moveRight(){
        character.position.x = character.position.x + 1
    }
    func moveLeft(){
        character.position.x = character.position.x - 1
    
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        moveRight()
        if character.position.x > 5{
            moveLeft()
        }
        
    }
}
