//
//  CalculatorBrain.swift
//  Calculator
//
//  Created by Filip Nilsson on 2016-05-18.
//  Copyright © 2016 Exyza. All rights reserved.
//

import Foundation

class CalculatorBrain
{
    private var accumulator = 0.0
    private var internalProgram = [AnyObject]()
    func setOperand(_ Operand: Double){
        accumulator = Operand
        internalProgram.append(Operand)
    }
    var operations: Dictionary<String,Operation> = [
        "π" : Operation.constant(M_PI),
        "e" : Operation.constant(M_E),
        "√" : Operation.unaryOperation(sqrt),
        "cos" : Operation.unaryOperation(cos),
        "sin" : Operation.unaryOperation(sin),
        "tan" : Operation.unaryOperation(tan),
        "×" : Operation.binaryOperation({ $0 * $1}),
        "÷" : Operation.binaryOperation({ $0 / $1}),
        "+" : Operation.binaryOperation({ $0 + $1}),
        "−" : Operation.binaryOperation({ $0 - $1}),
        "^2" : Operation.unaryOperation({ $0 * $0}),
        "ac" : Operation.constant(0),
        "(-)" : Operation.unaryOperation({ -$0}),
        "=": Operation.equals
    ]
    enum Operation{
        case constant(Double)
        case unaryOperation((Double)-> Double)
        case binaryOperation((Double,Double)-> Double)
        case equals
    }
    func performOperation(_ symbol: String){
        internalProgram.append(symbol)
        if let operation = operations[symbol]{
            switch operation{
            case .constant(let value):
                accumulator = value
            case .unaryOperation(let function):
                accumulator = function(accumulator)
            case .binaryOperation(let function):
                pending = PendingBinary(binaryFunction: function, firstOperand: accumulator)
            case .equals:
                if pending != nil{
                    accumulator = pending!.binaryFunction(pending!.firstOperand, accumulator)
                    pending = nil
                }
            }
        }
    }
    private var pending: PendingBinary?
    
    struct PendingBinary {
        var binaryFunction:(Double,Double)->Double
        var firstOperand: Double
    }
    typealias PropertyList = AnyObject
    
    var program: PropertyList
        {
        get{
            return internalProgram
        }
        set{
            clear()
            if let arrayOfOps = newValue as? [AnyObject]{
                for op in arrayOfOps {
                    if let Operand = op as? Double{
                    setOperand(Operand)
                    } else if let Operation = op as? String {
                        performOperation(Operation)
                    }
                }
            }
        }
    }
        func clear(){
            accumulator = 0.0
            pending = nil
            internalProgram.removeAll()
    }
    
    var result: Double {
        get{
            return accumulator
        }
    }
    
}
