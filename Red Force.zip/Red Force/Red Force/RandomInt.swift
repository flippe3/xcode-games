//
//  RandomInt.swift
//  Red Force
//
//  Created by Filip Nilsson on 2016-07-02.
//  Copyright © 2016 Exyza. All rights reserved.
//

import Foundation
import CoreGraphics

public extension Int{
    
    
    public static func random() -> Int{
        
        return Int(Int(arc4random()) / 0xFFFFFFFF)
    }
    
    public static func random(min: Int, max: Int) -> Int{
        
        return Int.random() * (max - min) + min 
    }
    
    
}
