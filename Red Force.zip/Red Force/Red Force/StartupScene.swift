//
//  GameScene.swift
//  Delete pls
//
//  Created by Filip Nilsson on 2016-06-15.
//  Copyright © 2016 Exyza. All rights reserved.
//

import SpriteKit
import GameplayKit

class StartupScene: SKScene {
    var playButton = SKSpriteNode(imageNamed: "PlayButton")
    var background1 = SKSpriteNode(imageNamed: "Main Menu")
    var highScoreLabel = SKLabelNode(fontNamed: "DJB Get Digital")
    var highScore = Int()
    var cam = SKCameraNode()
    
    func createScene(){
        //background
        background1.position = CGPoint(x: 0, y: 0)// 295
        background1.size = CGSize(width: self.frame.width, height: self.frame.height)
        background1.zPosition = -15
        self.addChild(background1)
        
        button()
        
        highScoreLabel.fontSize = 100
        highScoreLabel.zPosition = 12
        highScoreLabel.fontColor = SKColor.blue
        highScoreLabel.position = CGPoint(x: self.frame.midX, y: self.frame.midY - 600)
        let HighscoreDefault = UserDefaults.standard
        if HighscoreDefault.value(forKey: "Highscore") != nil{
            highScore = HighscoreDefault.value(forKey: "Highscore") as! NSInteger!
            highScoreLabel.text = NSString(format: "HIGHSCORE: %i", highScore) as String
        }
        else{
            highScoreLabel.text = "HIGHSCORE: 0"
        }
        self.addChild(highScoreLabel)
        
        
        
        
    }
    func button() {
        playButton.position = CGPoint(x: 0,y: 0)
        playButton.size = CGSize(width: self.frame.width - 200, height: self.frame.height - 1100)
        playButton.zPosition = 6
        self.addChild(playButton)
    }
    override func didMove(to view: SKView) {
        createScene()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches{
            let location = touch.location(in: self)
            if playButton.contains(location){
                print("Loading Scene")
                let moveScene = GameScene(fileNamed: "GameScene")
                let transition = SKTransition.fade(withDuration: 1)
                self.scene!.view?.presentScene(moveScene!, transition: transition)
                //self.scene?.view?.presentScene(moveScene)
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
