//
//  GameScene.swift
//  Red Force
//
//  Created by Filip Nilsson on 2016-06-04.
//  Copyright (c) 2016 Exyza. All rights reserved.
//

import SpriteKit

struct PhysicsCatagory {
    static let Ground : UInt32 = 0x1 << 1
    static let character : UInt32 = 0x1 << 2
    static let obstacle : UInt32 = 0x1 << 3
    static let balloon : UInt32 = 0x1 << 4
    static let Wall : UInt32 = 0x1 << 5
    static let Score : UInt32 = 0x1 << 6
}

class GameScene: SKScene, SKPhysicsContactDelegate {
    var character = SKSpriteNode()
    var obstacle = SKSpriteNode()
    var balloon = SKSpriteNode()
    var rope = SKSpriteNode()
    var ground = SKSpriteNode()
    var wallPair = SKNode()
    var moveAndRemove = SKAction()
    let spawn = SKAction()
    var delay = SKAction()
    var SpawnDelay = SKAction()
    var spawnDelayForever = SKAction()
    var distance = CGFloat()
    var movePipes = SKAction()
    var removePipes = SKAction.removeFromParent()
    var moveAndRemoveObstacle = SKAction()
    var gameStarted = Bool()
    var died = Bool()
    var score = Int()
    var highScore = Int()
    let scoreLbl = SKLabelNode()
    let timesPlayedLbl = SKLabelNode()
    var restartBTN = SKSpriteNode(imageNamed: "RestartBTN")
    var menuBTN = SKSpriteNode()
    var lvl1 = Bool()
    var highScoreLabel = SKLabelNode(fontNamed: "DJB Get Digital")
    let background1 = SKSpriteNode(imageNamed: "Wallpaper 4")
    let background2 = SKSpriteNode(imageNamed: "Wallpaper 5")
    var mainMenuBTN = SKSpriteNode(imageNamed: "backMenu")
    
    var bronzeTexture = SKTexture(imageNamed: "Bronze")
    var silverTexture = SKTexture(imageNamed: "Silver")
    var goldTexture = SKTexture(imageNamed: "Gold")
    var diamondTexture = SKTexture(imageNamed: "Diamond")
    var sweetTexture = SKTexture(imageNamed: "Sweet")
    
    var changeCharacter = false
    var oldScore = 0
    var y = CGFloat()
    var x = 1.8
    var b = CGFloat()
    var begun = Int()
    var textureAtlas = SKTextureAtlas()
    var textureArray = [SKTexture]()
    
    
    func restartScene(){
        self.removeAllChildren()
        self.removeAllActions()
        died = false
        gameStarted = false
        score = 0
        createScene()
    }
    func switchCharacter(){
        if score == 10{
            character.texture = bronzeTexture
        }
        if score == 20{
            character.texture = silverTexture
        }
        if score == 30{
            character.texture = goldTexture
        }
        if score == 40{
            character.texture = diamondTexture
        }
        if score >= 50{
            character.texture = sweetTexture
        }
    }
    
    func createScene(){
        self.physicsWorld.contactDelegate = self
        
        textureAtlas = SKTextureAtlas(named: "Images1")
        for i in 1...textureAtlas.textureNames.count{
            let name = "Bronze Animation \(i)"
            textureArray.append(SKTexture(imageNamed: name))
        }
        
        background1.anchorPoint = CGPoint.zero
        background1.position = CGPoint(x: -187.5, y: -333)// 295
        background1.size = CGSize(width: 375, height: 667)//375 667
        background1.zPosition = -15
        self.addChild(background1)
        
        background2.anchorPoint = CGPoint.zero
        background2.position = CGPoint(x:  -187.5, y: 333)
        background2.size = CGSize(width: 375, height: 667) // 435 900
        background2.zPosition = -15
        self.addChild(background2)
        
        scoreLbl.position = CGPoint(x: self.frame.midX, y: self.frame.midY + 250)
        scoreLbl.text = "\(score)"
        scoreLbl.fontName = "Tox Typewriter"
        scoreLbl.zPosition = 5
        scoreLbl.fontSize = 65
        scoreLbl.fontColor = SKColor.blue
        self.addChild(scoreLbl)
        
        ground = SKSpriteNode(imageNamed: "ground")
        ground.size = CGSize(width: self.frame.width, height: 55)
        ground.position = CGPoint(x: self.frame.midX, y: self.frame.midY - 100)
        
        ground.physicsBody = SKPhysicsBody(rectangleOf: ground.size)
        ground.physicsBody?.categoryBitMask = PhysicsCatagory.Ground
        ground.physicsBody?.collisionBitMask = PhysicsCatagory.character
        ground.physicsBody?.contactTestBitMask = PhysicsCatagory.character
        ground.physicsBody?.affectedByGravity = false
        ground.physicsBody?.isDynamic = false
        
        ground.zPosition = 3
        
        self.addChild(ground)
        
        character = SKSpriteNode(imageNamed:  "Character")
        character.size = CGSize(width: 45, height: 45)
        character.position = CGPoint(x: self.frame.midX - character.frame.midX / 2, y: 0)
        
        character.physicsBody = SKPhysicsBody(rectangleOf: character.size)
        character.physicsBody?.categoryBitMask = PhysicsCatagory.character
        character.physicsBody?.collisionBitMask = PhysicsCatagory.Wall | PhysicsCatagory.Ground
        character.physicsBody?.contactTestBitMask = PhysicsCatagory.Wall | PhysicsCatagory.Score | PhysicsCatagory.Ground
        character.physicsBody?.affectedByGravity = true
        character.physicsBody?.isDynamic = true
        
        let HighscoreDefault = UserDefaults.standard
        highScoreLabel.fontSize = 25
        highScoreLabel.zPosition = 12
        highScoreLabel.fontColor = SKColor.blue
        highScoreLabel.position = CGPoint(x: self.frame.midX + 110, y: self.frame.midY + 310)
        if HighscoreDefault.value(forKey: "Highscore") != nil{
            highScore = HighscoreDefault.value(forKey: "Highscore") as! NSInteger!
            highScoreLabel.text = NSString(format: "HIGHSCORE: %i", highScore) as String
        }
        
        
        let timesPlayedCount = UserDefaults.standard
        timesPlayedLbl.position = CGPoint(x: self.frame.midX / 2 , y: self.frame.midY - 250)
        timesPlayedLbl.text = "Times Played: \(begun)"
        timesPlayedLbl.fontName = "DJB Get Digital"
        timesPlayedLbl.fontSize = 35
        timesPlayedLbl.fontColor = SKColor.darkGray
        timesPlayedLbl.zPosition = 15
        if timesPlayedCount.value(forKey: "TimesPlayed") != nil{
            begun = timesPlayedCount.value(forKey: "TimesPlayed") as! NSInteger!
            timesPlayedLbl.text = NSString(format: "Times Played: %i",begun) as String
            
        }
        self.addChild(timesPlayedLbl)
        
        
        self.addChild(highScoreLabel)
        
        
        character.zPosition = 2
        character.addChild(balloon)
        self.addChild(character)
        
    }
    
    func createBTN(){
    
        character.removeAction(forKey: "Ani")
        restartBTN.size = CGSize(width: 200, height: 87)
        restartBTN.position = CGPoint(x: self.frame.midX, y: self.frame.midY)
        restartBTN.zPosition = 6
        restartBTN.setScale(0)
        self.addChild(restartBTN)
        
        restartBTN.run(SKAction.scale(to: 1, duration: 1))
        
    }
    func createPowerDowns(){
        obstacle = SKSpriteNode(imageNamed: "Obstacle")
        obstacle.size = CGSize(width: 25,height: 45)
        
        let randomPos = CGFloat.random(min: -110, max: 110)// 180 150
        obstacle.position = CGPoint(x: randomPos,y: 150)
        
        obstacle.physicsBody = SKPhysicsBody(rectangleOf: obstacle.size)
        obstacle.physicsBody?.affectedByGravity = true
        obstacle.physicsBody?.categoryBitMask = PhysicsCatagory.obstacle
        obstacle.physicsBody?.contactTestBitMask = PhysicsCatagory.character | PhysicsCatagory.Wall
        obstacle.zPosition = 2
        obstacle.physicsBody?.isDynamic = true 
        
        self.addChild(obstacle)
    }
    func Spawning(){
        let spawn = SKAction.run({
            () in
            self.createWalls()
        })
        
        delay = SKAction.wait(forDuration: x)
        SpawnDelay = SKAction.sequence([spawn, delay])
        spawnDelayForever = SKAction.repeatForever(SpawnDelay)
        self.run(spawnDelayForever, withKey: "SpawnDelay")
        distance = CGFloat(self.frame.width + wallPair.frame.width + 105)
        movePipes = SKAction.moveBy(x: 0, y: -distance - 600, duration: TimeInterval(0.02 * distance))
        removePipes = SKAction.removeFromParent()
        moveAndRemove = SKAction.sequence([movePipes, removePipes])
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if (gameStarted == false){
            //character.run(SKAction.repeatForever(SKAction.animate(with: textureArray, timePerFrame: 0.4)), withKey: "Ani")
            gameStarted =  true
            x = 1.9
            
            //if wallPair.speed != 0.65{
            Spawning()
            //}
            createPowerDowns()
            
            let wait = SKAction.wait(forDuration: 15, withRange: 15)// fordur 25
            let spawn = SKAction.run {
                self.createPowerDowns()
            }
            
            let sequence = SKAction.sequence([wait, spawn])
            self.run(SKAction.repeatForever(sequence))
            
            begun = begun + 1
            timesPlayedLbl.text = NSString(format: "Times Played: %i", begun) as String
            let timesPlayedCount = UserDefaults.standard
            timesPlayedCount.setValue(begun, forKey: "TimesPlayed")
            
            character.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
            //character.physicsBody?.applyImpulse(CGVector(dx: 0,dy: 80))
        }
        else{
            
            if died == true{
            }
            else{
                character.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
                //  character.physicsBody?.applyImpulse(CGVector(dx: 0,dy: 55))
            }
        }
        for touch in touches{
            let location = touch.location(in: self)
            if died == true{
                if restartBTN.contains(location){
                    restartScene()
                }
            }
        }
    }
    
    override func didMove(to view: SKView) {
        createScene()
    }
    func fast(){
        oldScore = score
        removeAction(forKey: "SpawnDelay")
        x = 0.5
        //self.run(spawnDelayForever)
        Spawning()
        wallPair.removeFromParent()
        moveAndRemove.speed = 3
        changeCharacter = true
        print("fast")
    }
    func big(){
        oldScore = score
        changeCharacter = true
        character.size = CGSize(width: 65, height:65)
        character.physicsBody = SKPhysicsBody(rectangleOf: character.size)
        character.position = CGPoint(x: self.x,y: 15)
        //balloon.position.y = 15
        character.physicsBody?.categoryBitMask = PhysicsCatagory.character
        character.physicsBody?.collisionBitMask = PhysicsCatagory.Wall | PhysicsCatagory.Ground
        character.physicsBody?.contactTestBitMask = PhysicsCatagory.Wall | PhysicsCatagory.Score | PhysicsCatagory.Ground
        print("big")
    }
    func small(){
        oldScore = score
        changeCharacter = true
        character.size = CGSize(width: 25,height: 25)
        character.physicsBody = SKPhysicsBody(rectangleOf: character.size)
        character.physicsBody?.categoryBitMask = PhysicsCatagory.character
        character.physicsBody?.collisionBitMask = PhysicsCatagory.Wall | PhysicsCatagory.Ground
        character.physicsBody?.contactTestBitMask = PhysicsCatagory.Wall | PhysicsCatagory.Score | PhysicsCatagory.Ground
        print("small")
    }
    func didBegin(_ contact: SKPhysicsContact) {
        let firstBody = contact.bodyA
        let secondBody = contact.bodyB
        switch true {
        case firstBody.categoryBitMask == PhysicsCatagory.Score && secondBody.categoryBitMask == PhysicsCatagory.character:
            score += 1
            scoreLbl.text = "\(score)"
            if score > highScore{
                highScore = score
                highScoreLabel.text = NSString(format: "HIGHSCORE: %i", highScore) as String
                let HighscoreDefault = UserDefaults.standard
                HighscoreDefault.setValue(highScore, forKey: "Highscore")
            }
            switchCharacter()
            print(highScore)
            print(score)
            firstBody.node?.removeFromParent()
            break
        case firstBody.categoryBitMask == PhysicsCatagory.character && secondBody.categoryBitMask == PhysicsCatagory.Score:
            score += 1
            scoreLbl.text = "\(score)"
            if score > highScore{
                highScore = score
                highScoreLabel.text = NSString(format: "HIGHSCORE: %i", highScore) as String
                let HighscoreDefault = UserDefaults.standard
                HighscoreDefault.setValue(highScore, forKey: "Highscore")
                HighscoreDefault.synchronize()
            }
            switchCharacter()
            print(highScore)
            print(score)
            secondBody.node?.removeFromParent()
            break
        case firstBody.categoryBitMask == PhysicsCatagory.Wall && secondBody.categoryBitMask == PhysicsCatagory.obstacle:
            obstacle.removeFromParent()
            break
        case firstBody.categoryBitMask == PhysicsCatagory.obstacle && secondBody.categoryBitMask == PhysicsCatagory.Wall:
            obstacle.removeFromParent()
            break
            
        case firstBody.categoryBitMask == PhysicsCatagory.obstacle && secondBody.categoryBitMask == PhysicsCatagory.character:
            let randomNum = CGFloat.random(min: 0, max: 3)
            print(Int(randomNum))
            if (Int(randomNum)) == 0{
                small()
            }
            if (Int(randomNum)) == 1{
                big()
            }
            if (Int(randomNum)) == 2{
                fast()
            }
            firstBody.node?.removeFromParent()
            break
        case firstBody.categoryBitMask == PhysicsCatagory.character && secondBody.categoryBitMask == PhysicsCatagory.obstacle:
            let randomNum = CGFloat.random(min: 0, max: 3)
            print(randomNum)
            if (Int(randomNum)) == 0{
                small()
            }
            if (Int(randomNum)) == 1{
                big()
            }
            if (Int(randomNum)) == 2{
                fast()
            }
            secondBody.node?.removeFromParent()
            
        case firstBody.categoryBitMask == PhysicsCatagory.character && secondBody.categoryBitMask == PhysicsCatagory.Wall || firstBody.categoryBitMask == PhysicsCatagory.Wall && secondBody.categoryBitMask == PhysicsCatagory.character:
            enumerateChildNodes(withName: "wallPair", using: ({
                (node, error) in
                node.speed = 0
                self.removeAllActions()
                
            }))
            if died == false{
                died = true
                character.run(SKAction.fadeOut(withDuration: 1))
                createBTN()
            }
        default:
            break
        }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in (touches){
            let location = touch.location(in: self)
            if died == false{
                if self.contains(location){
                    character.position.x = location.x
                }
            }
        }
    }
    
    func createWalls(){
        let scoreNode = SKSpriteNode()
        scoreNode.size = CGSize(width: 170, height: 3)
        scoreNode.position = CGPoint(x: self.frame.width / 2 + 185, y: self.frame.height / 2 + 100) // x: self.frame.width + 25, y: self.frame.height /2
        scoreNode.physicsBody = SKPhysicsBody(rectangleOf: scoreNode.size)
        scoreNode.physicsBody?.affectedByGravity = false
        scoreNode.physicsBody?.isDynamic = false
        scoreNode.physicsBody?.categoryBitMask = PhysicsCatagory.Score
        scoreNode.physicsBody?.collisionBitMask = 0
        scoreNode.physicsBody?.contactTestBitMask = PhysicsCatagory.character | PhysicsCatagory.balloon
        scoreNode.color = SKColor.green
        
        wallPair = SKNode()
        wallPair.name = "wallPair"
        
        let leftWall = SKSpriteNode(imageNamed: "Better Spikes")
        let rightWall = SKSpriteNode(imageNamed: "Better Spikes")
        
        leftWall.position = CGPoint(x: self.frame.width / 2, y: self.frame.height / 2 + 100)
        rightWall.position = CGPoint(x: (self.frame.width / 2) + 370, y: self.frame.height / 2 + 100) // + 450
        
        leftWall.size = CGSize(width: 250, height: 57)
        rightWall.size = CGSize(width: 250, height: 57) // 340 x 85
        
        leftWall.physicsBody = SKPhysicsBody(rectangleOf: leftWall.size)
        leftWall.physicsBody?.categoryBitMask = PhysicsCatagory.Wall
        leftWall.physicsBody?.contactTestBitMask = PhysicsCatagory.character
        leftWall.physicsBody?.isDynamic = false
        leftWall.physicsBody?.affectedByGravity = false
        
        rightWall.physicsBody = SKPhysicsBody(rectangleOf: rightWall.size)
        rightWall.physicsBody?.categoryBitMask = PhysicsCatagory.Wall
        rightWall.physicsBody?.contactTestBitMask = PhysicsCatagory.character
        rightWall.physicsBody?.isDynamic = false
        rightWall.physicsBody?.affectedByGravity = false
        
        wallPair.addChild(leftWall)
        wallPair.addChild(rightWall)
        
        let randomPosition = CGFloat.random(min: -475, max: -250)
        wallPair.position.x = wallPair.position.x + randomPosition
        
        wallPair.addChild(scoreNode)
        
        wallPair.zPosition = 2
        wallPair.run(moveAndRemove)
        
        
        self.addChild(wallPair)
        wallPair.speed = wallPair.speed * 1.5
    }
    override func update(_ currentTime: TimeInterval) {
        /* Called before each frame is rendered */
        if gameStarted == true{
            if died == false{
                if changeCharacter == true{
                    //let delay = Int.random(min: 0, max: 10)
                    if score == oldScore + 5{
                        character.size = CGSize(width: 45, height:45)
                        removeAction(forKey: "SpawnDelay")
                        x = 1.9
                        Spawning()
                        //self.removeAction(forKey: "SpawnDelay")
                        //self.run(spawnDelayForever)
                        //wallPair.run(moveAndRemove)
                        //wallPair.speed = 1.9
                        moveAndRemove.speed = 1
                        //character.speed = 1
                        character.physicsBody = SKPhysicsBody(rectangleOf: character.size)
                        character.physicsBody?.affectedByGravity = true
                        character.physicsBody?.categoryBitMask = PhysicsCatagory.character
                        character.physicsBody?.collisionBitMask = PhysicsCatagory.Wall | PhysicsCatagory.Ground
                        character.physicsBody?.contactTestBitMask = PhysicsCatagory.Wall | PhysicsCatagory.Score | PhysicsCatagory.Ground
                    }
                }
                background1.position = CGPoint(x: background1.position.x, y: background1.position.y - 0.5)
                background2.position = CGPoint(x: background2.position.x, y: background2.position.y - 0.5)
                
                if(background1.position.y <= -background1.size.height - 333)
                {
                    background1.position = CGPoint(x: background2.position.x,y: background2.size.height - 343)
                }
                
                if(background2.position.y <= -background2.size.height - 333)
                {
                    background2.position = CGPoint(x: background1.position.x, y: background1.size.height - 343)
                }
            }
            
        }
    }
}
