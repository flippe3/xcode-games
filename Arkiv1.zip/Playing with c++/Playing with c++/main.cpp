//
//  main.cpp
//  Playing with c++
//
//  Created by Filip Nilsson on 2016-10-26.
//  Copyright © 2016 Exyza. All rights reserved.
//

#include <iostream>
using namespace std;

int main() {
    string name;
    cout << "Enter your name: ";
    cin >> name;
    cout << name << endl;
}
