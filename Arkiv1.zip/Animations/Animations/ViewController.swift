//
//  ViewController.swift
//  Animations
//
//  Created by Filip Nilsson on 2016-09-11.
//  Copyright © 2016 Exyza. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myImageView: UIImageView!
    var myImages = [UIImage]()
    
    @IBAction func startKey(_ sender: AnyObject) {
        myImageView.startAnimating()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for i in 1...5{
            myImages.append(UIImage(named: "Bronze Animation\(i)")!)
        }
        myImageView.animationImages = myImages
    }

}

