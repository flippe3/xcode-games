//
//  GameScene.swift
//  Katamino
//
//  Created by Filip Nilsson on 2016-10-01.
//  Copyright © 2016 Exyza. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    override func didMove(to view: SKView) {
        
        ScenesnTextures()
    }
    func ScenesnTextures()
    {
        createBlocks(count: 9)
    }
    /*
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in (touches){
     
            let location = touch.location(in: self)
            if self.contains(K1.position){
                K1.position = location
            }
            else if self.contains(K2.position)
            {
                K2.position = location
            }
            else if self.contains(K9.position)
            {
                K9.position = location
            }
        }
    }
 */
  
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
    func createBlocks(count: Int) -> [SKSpriteNode]{
        var yDistance = CGFloat()
        var xDistance = CGFloat()
        yDistance = 150
        xDistance = 100
        var blocks = [SKSpriteNode]()
        for i in 0..<count + 1{
            let sprite = SKSpriteNode(imageNamed: "K\(i + 1)PNG")
            sprite.position = CGPoint(x: xDistance, y: yDistance)
            sprite.size = CGSize(width: 50, height: 50)
            self.addChild(sprite)
            
            if(i % 2 != 0){
                xDistance = 100
                yDistance -= 75
            }
            else{
                xDistance = 25
            }
            
        }
        
        return blocks
    }
}
