//
//  GameScene.swift
//  Pilot
//
//  Created by Filip Nilsson on 2016-09-19.
//  Copyright © 2016 Exyza. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    var J29 = SKSpriteNode()
    var WeaponLeft = SKSpriteNode()
    var WeaponRight = SKSpriteNode()
    var J34 = SKSpriteNode()
    
    override func didMove(to view: SKView) {
        J29.texture = SKTexture(imageNamed: "J29")
        J29.size = CGSize(width: 200, height: 200)
        J29.position = CGPoint(x: 0, y: (self.frame.height / -3) - 45)
        
        J34.texture = SKTexture(imageNamed: "	")
        
        
        self.addChild(J29)
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in (touches){
            let location = touch.location(in: self)
                if self.contains(location){
                    J29.position.x = location.x

            }
        }
    }
    func randomAttackers()
    {
        
    }

    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
