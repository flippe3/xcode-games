//
//  GameScene.swift
//  Project Dodge
//
//  Created by Filip Nilsson on 2016-10-22.
//  Copyright © 2016 Exyza. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    var mainCharacter = SKSpriteNode()
    var dodgeBlocks = SKSpriteNode()
    
    func GenerateScene()
    {
        mainCharacter.color = #colorLiteral(red: 0.06414528936, green: 0.9068052173, blue: 0.1070847809, alpha: 1)
        mainCharacter.size = CGSize(width: 100, height: 100)
        mainCharacter.position = CGPoint(x: 0,y: -200)
        
        mainCharacter.physicsBody?.isDynamic = true
        
        self.addChild(mainCharacter)
        
    }
    
    func GenerateDodgeBlocks()
    {
        dodgeBlocks.color = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
        dodgeBlocks.size = CGSize(width: 25,height: 25)
        let randomPos = CGFloat.random(min: -300, max: 300)
        dodgeBlocks.position = CGPoint(x: randomPos,y:250)
        
        dodgeBlocks.physicsBody = SKPhysicsBody(rectangleOf: dodgeBlocks.size)
        dodgeBlocks.physicsBody?.affectedByGravity = true
        dodgeBlocks.physicsBody?.isDynamic = true
 
        self.addChild(dodgeBlocks)
    }
    func spawnObjects()
    {
        let spawn = SKAction.run {
            self.GenerateDodgeBlocks()
        }
        
        let wait = SKAction.wait(forDuration: 5)
        let sequence = SKAction.sequence([wait, spawn])
        
        run(SKAction.repeatForever(sequence))
    }
 
    override func didMove(to view: SKView) {
        GenerateScene()
        
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in (touches){
            let location = touch.location(in: self)
            if self.contains(location){
                mainCharacter.position.x = location.x
            }  
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        spawnObjects()
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
    }
}
