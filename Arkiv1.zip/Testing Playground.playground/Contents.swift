//: Playground - noun: a place where people can play

import UIKit

var str = "🍎🍏"

var str2 = "🔫"

var fem = 2.0

var slutSvar = str + str2



print("Detta är hur man " + str + " plussar strings")

var tal = 1453

var svar = tal - (tal % 100)