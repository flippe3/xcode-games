//
//  main.swift
//  Snabbtest 1
//
//  Created by Filip Nilsson on 2016-11-17.
//  Copyright © 2016 Exyza. All rights reserved.
//

import Foundation

print("Hello, World!")

