//
//  ViewController.swift
//  TextThingy
//
//  Created by Filip Nilsson on 2016-09-12.
//  Copyright © 2016 Exyza. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var FirstSquare: UITextField!
    @IBOutlet weak var SecondSquare: UITextField!
    @IBOutlet weak var ThirdSquare: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        FirstSquare.backgroundColor = UIColor.red()
        SecondSquare.backgroundColor = UIColor.blue()
        ThirdSquare.backgroundColor = UIColor.cyan()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

