//
//  GameScene.swift
//  NightGame
//
//  Created by Filip Nilsson on 2016-09-13.
//  Copyright © 2016 Exyza. All rights reserved.
//

import SpriteKit
//import GameplayKit

class GameScene: SKScene {
    
    var Wall = SKSpriteNode()
    var Ball = SKSpriteNode()
    var JumpBlock = SKSpriteNode()
    var Basket = SKSpriteNode()
    var BasketSideL = SKSpriteNode()
    var BasketSideR = SKSpriteNode()
    var Ground = SKSpriteNode()
    //var Wallpaper = SKTexture(imageNamed: "WTF")
    
    override func didMove(to view: SKView) {
        createScene()
    }
    func createScene(){
        
        Wall = SKSpriteNode(imageNamed: "WallTex")
        Wall.size = CGSize(width: 30, height: self.frame.height / 2)
        Wall.position = CGPoint(x: self.frame.midX,y: -250)
        Wall.physicsBody = SKPhysicsBody(rectangleOf: Wall.size)
        Wall.physicsBody?.affectedByGravity = false
        Wall.physicsBody?.isDynamic = false
        
        Ground = SKSpriteNode(imageNamed: "WallTex")
        Ground.size = CGSize(width: 1000, height: 30)
        Ground.position = CGPoint(x: self.frame.midX,y: -200)
        Ground.physicsBody = SKPhysicsBody(rectangleOf: Ground.size)
        Ground.physicsBody?.affectedByGravity = false
        Ground.physicsBody?.isDynamic = false
        
        Ball = SKSpriteNode(imageNamed: "BallTex")
        Ball.size = CGSize(width: 50 ,height: 50)
        Ball.position = CGPoint(x: -(self.frame.width / 4), y: 0)
        Ball.physicsBody = SKPhysicsBody(circleOfRadius: Ball.size.width / 2)
        Ball.physicsBody?.affectedByGravity = true
        Ball.physicsBody?.isDynamic = true
        
        Basket = SKSpriteNode(imageNamed: "WallTex")
        Basket.size = CGSize(width: 100, height: 30)
        Basket.position = CGPoint(x: self.frame.width / 4,y: -30)
        Basket.physicsBody = SKPhysicsBody(rectangleOf: Basket.size)
        Basket.physicsBody?.affectedByGravity = false
        Basket.physicsBody?.isDynamic = false
        BasketSideL = SKSpriteNode(imageNamed: "WallTex")
        BasketSideL.size = CGSize(width: 30, height: 100)
        BasketSideL.position = CGPoint(x: (self.frame.width / 4) - 55,y: 5)
        BasketSideL.physicsBody = SKPhysicsBody(rectangleOf: BasketSideL.size)
        BasketSideL.physicsBody?.affectedByGravity = false
        BasketSideL.physicsBody?.isDynamic = false
        BasketSideR = SKSpriteNode(imageNamed: "WallTex")
        BasketSideR.size = CGSize(width: 30, height: 100)
        BasketSideR.position = CGPoint(x: (self.frame.width / 4 ) + 55,y: 5)
        BasketSideR.physicsBody = SKPhysicsBody(rectangleOf: BasketSideR.size)
        BasketSideR.physicsBody?.affectedByGravity = false
        BasketSideR.physicsBody?.isDynamic = false
        
        
        self.addChild(Wall)
        self.addChild(Ball)
        self.addChild(Basket)
        self.addChild(Ground)
        self.addChild(BasketSideL)
        self.addChild(BasketSideR)
    }
    func touchDown(atPoint pos : CGPoint) {
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in (touches){
            let location = touch.location(in: self)
            if self.contains(location){
                Ball.position = location
            }
        }
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
