#include <iostream>
#include <strings>

int main() {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
