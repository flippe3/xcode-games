//
//  Menu.swift
//  Throw
//
//  Created by Filip Nilsson on 2016-09-14.
//  Copyright © 2016 Exyza. All rights reserved.
//

import SpriteKit
import GameplayKit

class StartupScene: SKScene {
    var playButton = SKSpriteNode(imageNamed: "PlayButton")
    var background1 = SKSpriteNode(imageNamed: "Main Menu")
    var highScoreLabel = SKLabelNode(fontNamed: "DJB Get Digital")
    var highScore = Int()
    var cam = SKCameraNode()
    
    func createScene(){
        //background
        background1.position = CGPoint(x: 0, y: 0)// 295
        background1.size = CGSize(width: self.frame.width, height: self.frame.height)
        background1.zPosition = -15
        self.addChild(background1)
        
        button()
        
    }
    func button() {
        playButton.position = CGPoint(x: 0,y: 0)
        playButton.size = CGSize(width: self.frame.width - 200, height: self.frame.height - 1100)
        playButton.zPosition = 6
        self.addChild(playButton)
    }
    override func didMove(to view: SKView) {
        createScene()
    }
    
    func touchDown(atPoint pos : CGPoint) {
        
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        
    }
    
    func touchUp(atPoint pos : CGPoint) {
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches{
            let location = touch.location(in: self)
            if playButton.contains(location){
                print("Loading Scene")
                let moveScene = GameScene(fileNamed: "GameScene")
                let transition = SKTransition.fade(withDuration: 1)
                self.scene!.view?.presentScene(moveScene!, transition: transition)
                //self.scene?.view?.presentScene(moveScene)
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
