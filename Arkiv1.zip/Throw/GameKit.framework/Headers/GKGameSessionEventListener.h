//
//  GKGameSessionEventListener.h
//  Game Center
//
//  Copyright 2016 Apple Inc. All rights reserved.
//

#import "GKGameSession.h"

@protocol GKGameSessionEventListener <NSObject>
@optional
- (void)session:(GKGameSession *)session didAddPlayer:(GKCloudPlayer *)player;
- (void)session:(GKGameSession *)session didRemovePlayer:(GKCloudPlayer *)player;
- (void)session:(GKGameSession *)session player:(GKCloudPlayer *)player didChangeConnectionState:(GKConnectionState)newState;
- (void)session:(GKGameSession *)session player:(GKCloudPlayer *)player didSaveData:(NSData *)data;
- (void)session:(GKGameSession *)session didReceiveData:(NSData *)data fromPlayer:(GKCloudPlayer *)player;
- (void)session:(GKGameSession *)session didReceiveMessage:(NSString *)message withData:(NSData *)data fromPlayer:(GKCloudPlayer *)player;

// A player has requested to play a session with the given other players. This could be initiated from an iMessage link or Siri, for example.
- (void)player:(GKCloudPlayer *)player requestedSessionWithPlayers:(NSArray<GKCloudPlayer *> *)players;
@end

@interface GKGameSession (GKGameSessionEventListener)
+ (void)addEventListener:(NSObject<GKGameSessionEventListener> *)listener;
+ (void)removeEventListener:(NSObject<GKGameSessionEventListener> *)listener;
@end
