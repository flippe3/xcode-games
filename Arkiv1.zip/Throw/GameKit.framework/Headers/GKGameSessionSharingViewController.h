//
//  GKGameSessionSharingViewController.h
//  GameCenterUI
//
//  Created by Alan Berfield on 2/20/16.
//  Copyright © 2016 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#if TARGET_OS_TV

@class GKGameSession;
@protocol GKGameSessionSharingViewControllerDelegate;


NS_ASSUME_NONNULL_BEGIN

@interface GKGameSessionSharingViewController : UIViewController
@property (nonatomic, readonly, strong) GKGameSession *session;
@property (nonatomic, weak, nullable) id<GKGameSessionSharingViewControllerDelegate> delegate;

- (instancetype)initWithSession:(GKGameSession *)session;

@end


@protocol GKGameSessionSharingViewControllerDelegate <NSObject>
- (void)sharingViewController:(GKGameSessionSharingViewController *)viewController didFinishWithError:(NSError *)error;
@end

NS_ASSUME_NONNULL_END


#endif
