//
//  GKCloudPlayer.h
//  Game Center
//
//  Copyright 2012-2016 Apple Inc. All rights reserved.
//

#import <GameKit/GKBasePlayer.h>

@interface GKCloudPlayer : GKBasePlayer
#if !__OBJC2__
{
    NSString *_identifier;
    NSString *_name;
}
#endif

// Retrieve a player instance representing the active iCloud account. Returns nil and an error if no iCloud is currently signed in.
+ (void)getCurrentSignedInPlayer:(void(^)(GKCloudPlayer *player, NSError *error))handler;

@end
