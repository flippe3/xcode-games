//
//  RandomFunction.swift
//  Red Force
//
//  Created by Filip Nilsson on 2016-06-04.
//  Copyright © 2016 Exyza. All rights reserved.
//

import Foundation
import CoreGraphics

public extension CGFloat{
    
    
    public static func random() -> CGFloat{
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    
    public static func random(min : CGFloat, max : CGFloat) -> CGFloat{
        return CGFloat.random() * (max - min) + min
    }
    
    
}
public extension Int{
    
    
    public static func random() -> Int{
        return Int(Int(arc4random()) / 0xF)
    }
    
    public static func random(min : Int, max : Int) -> Int{
        return Int.random() * (max - min) + min
    }
    
    
}
