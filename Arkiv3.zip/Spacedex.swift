//
//  Spacedex.swift
//  Delete pls
//
//  Created by Filip Nilsson on 2016-06-15.
//  Copyright © 2016 Exyza. All rights reserved.
//

import SpriteKit
import GameplayKit

class Spacedex: SKScene{
    var SpaceDexArray = ["SP_SpaceDex001","SP_SpaceDex002","SP_SpaceDex003","SP_SpaceDex004","SP_SpaceDex005"]
    var count = 0
    var named: String = ""
    var bg = SKSpriteNode(imageNamed: "SP_Background2")
    var btn_back = SKSpriteNode(imageNamed: "SP_Back")
    var img = SKSpriteNode()
    
    override func didMove(to view: SKView) {
        named = SpaceDexArray[count]
        img = SKSpriteNode(imageNamed: "\(named)")
        
        btn_back.position = CGPoint(x: self.frame.minX + 150,y: self.frame.minY + 60)
        btn_back.zPosition = 1
        
        img.size = CGSize(width: 700, height:700)
        img.zPosition = -1
        
        self.addChild(bg)
        self.addChild(img)
        self.addChild(btn_back)
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with: UIEvent?){
        for touch in touches
        {
            eachTouch()
            let location = touch.location(in: self)
            if (btn_back.contains(location))
            {
                print("Load MainMenu")
                if let view = self.view{
                    if let scene = MainMenu(fileNamed: "MainMenu") {
                        scene.scaleMode = .aspectFill
                        view.presentScene(scene, transition: SKTransition.fade(withDuration: 1))
                    }
                }
            }
        }
        
    }
    
    func eachTouch ()
    {
        
        img.removeFromParent()
        if(count >= 5)
        {
            count = 0
        }
        named = SpaceDexArray[count]
        img = SKSpriteNode(imageNamed: "\(named)")
        img.size = CGSize(width: 700, height:700)
        count += 1
        self.addChild(img)
    }
}
