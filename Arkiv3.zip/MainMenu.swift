//
//  GameScene.swift
//  Delete pls
//
//  Created by Filip Nilsson on 2016-06-15.
//  Copyright © 2016 Exyza. All rights reserved.
//

import SpriteKit
import GameplayKit

class MainMenu: SKScene {
    var background = SKSpriteNode(imageNamed: "SP_Startmenu2")
    var btn_play = SKSpriteNode(imageNamed: "SP_BTN_Play")
    var btn_scoreboard = SKSpriteNode(imageNamed: "PS_BTN_Scoreboard")
    var btn_spacedex = SKSpriteNode(imageNamed: "PS_BTN_Spacedex")
    var btn_distance = 50
    func createScene(){
        background.position = CGPoint(x:0, y:0)
        background.size = CGSize(width: self.frame.width, height: self.frame.height)
        background.zPosition = -15
        
        btn_play.position = CGPoint(x: self.frame.midX, y: self.frame.midY - btn_play.size.height - 50)
        btn_play.zPosition = 5
        
        btn_scoreboard.position = CGPoint(x: self.frame.midX, y: self.frame.midY - btn_play.size.height - 200)
        btn_scoreboard.zPosition = 5
        
        btn_spacedex.position = CGPoint(x: self.frame.midX, y: self.frame.midY - btn_play.size.height - 350)
        btn_spacedex.zPosition = 5
        
        
        print("Creating Scene")
        self.addChild(background)
        self.addChild(btn_play)
        self.addChild(btn_scoreboard)
        self.addChild(btn_spacedex)
        
    }
    
    override func didMove(to view: SKView) {
        createScene()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches{
            let location = touch.location(in: self)
            if btn_play.contains(location){
                print("Loading GameScene")
                let moveScene = GameScene(fileNamed: "GameScene")
                let transition = SKTransition.fade(withDuration: 1)
                self.scene!.view?.presentScene(moveScene!, transition: transition)
            }
            else if btn_spacedex.contains(location)
            {
                if let view = self.view{
                    if let scene = Spacedex(fileNamed: "Spacedex") {
                        scene.scaleMode = .aspectFill
                        view.presentScene(scene, transition: SKTransition.fade(withDuration: 0.5))
                    }
                }
            }
        }
    }
}
