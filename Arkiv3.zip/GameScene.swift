//
//  GameScene.swift
//  Space Penguin
//
//  Created by Filip Nilsson on 2016-12-06.
//  Copyright © 2016 space_makers. All rights reserved.
//

import SpriteKit
import GameplayKit

struct PhysicsCatagory {
    static let character : UInt32 = 0x1 << 1
    static let meteorite : UInt32 = 0x1 << 2
    static let bullet : UInt32 = 0x1 << 3
    static let deletenode_top : UInt32 = 0x1 << 4
    static let deletenode_bot : UInt32 = 0x1 << 5
}

class GameScene: SKScene, SKPhysicsContactDelegate {
    var penguin_character = SKSpriteNode(imageNamed: "SP_FrontsidepeguinGun2")
    var died = false
    var background1 = SKSpriteNode(imageNamed: "SP_Background2")
    var background2 = SKSpriteNode(imageNamed: "SP_Background2")
    var meteorite = SKSpriteNode(imageNamed: "SP_Pluto_lvl1")
    var pluto = SKSpriteNode(imageNamed: "SP_Pluto")
    var explosion = SKSpriteNode(imageNamed: "SP_Explosion")
    var gameover = SKSpriteNode(imageNamed: "SP_GameOverText")
    var gameover_score = SKSpriteNode(imageNamed: "SP_Score&Best")
    var playagain = SKSpriteNode(imageNamed: "SP_BTN_PlayAgain" )
    var mainmenu = SKSpriteNode(imageNamed: "SP_BTN_MainMenu")
    let bullet = SKSpriteNode(imageNamed: "SP_Bullet")
    var delete_node_bot = SKSpriteNode()
    var delete_node_top = SKSpriteNode()
    var hits = 0
    var score = 0
    var highscore = Int()
    let scoreLbl = SKLabelNode()
    let highscoreLbl = SKLabelNode()
    var end = false
    var grav = -0.2
    var lastxpos = CGFloat()
    var oldten = 0
    var plusx = CGFloat()
    
    func createScene()
    {
        died = false
        end = false
        print("Loaded Gamescene")
        self.physicsWorld.contactDelegate = self
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -0.2)
        penguin_character.position = CGPoint(x: self.frame.midX, y: self.frame.midY - 225)
        penguin_character.size = CGSize(width: 80, height: 100)
        penguin_character.zPosition = 1
        
        penguin_character.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 20, height: 40))
        penguin_character.physicsBody?.categoryBitMask = PhysicsCatagory.character
        penguin_character.physicsBody?.collisionBitMask = PhysicsCatagory.meteorite
        penguin_character.physicsBody?.contactTestBitMask = PhysicsCatagory.meteorite
        penguin_character.physicsBody?.affectedByGravity = false
        penguin_character.physicsBody?.isDynamic = false
        
        delete_node_bot.position = CGPoint(x: self.frame.midX,y: self.frame.minY - 150)
        delete_node_bot.size = CGSize(width: self.frame.width + 300, height: 5)
        delete_node_bot.physicsBody = SKPhysicsBody(rectangleOf: delete_node_bot.size)
        delete_node_bot.physicsBody?.categoryBitMask = PhysicsCatagory.deletenode_bot
        delete_node_bot.physicsBody?.collisionBitMask = PhysicsCatagory.meteorite
        delete_node_bot.physicsBody?.contactTestBitMask = PhysicsCatagory.meteorite
        delete_node_bot.physicsBody?.affectedByGravity = false
        delete_node_bot.physicsBody?.isDynamic = false
        
        delete_node_top.position = CGPoint(x: self.frame.midX,y: self.frame.maxY + 5)
        delete_node_top.size = CGSize(width: self.frame.width + 300, height: 5)
        delete_node_top.color = UIColor.blue
        delete_node_top.physicsBody = SKPhysicsBody(rectangleOf: delete_node_top.size)
        delete_node_top.physicsBody?.categoryBitMask = PhysicsCatagory.deletenode_top
        delete_node_top.physicsBody?.collisionBitMask = PhysicsCatagory.bullet
        delete_node_top.physicsBody?.contactTestBitMask = PhysicsCatagory.bullet
        delete_node_top.physicsBody?.affectedByGravity = false
        delete_node_top.physicsBody?.isDynamic = false
        delete_node_top.zPosition = 5
        
        scoreLbl.position = CGPoint(x: self.frame.minX + 25, y: self.frame.maxY - 50)
        scoreLbl.text = "\(score)"
        scoreLbl.fontName = "Pixeled"
        scoreLbl.zPosition = 5
        scoreLbl.fontSize = 55
        scoreLbl.fontColor = SKColor.yellow
        
        
        pluto.position = CGPoint(x: 0, y: -250)
        pluto.size = CGSize(width: 1400,height: 1400)
        // Spawning Meteorites
        let wait = SKAction.wait(forDuration: 1, withRange: 1)
        let spawn = SKAction.run {
            self.meteorites_aka_gummiband()
        }
        let sequence = SKAction.sequence([wait, spawn])
        self.run(SKAction.repeatForever(sequence))
        // Spawning bullets
        let bullet_wait = SKAction.wait(forDuration: 0.25)
        let bullet_spawn = SKAction.run {
            self.spawnBullets()
        }
        let bullet_sequence = SKAction.sequence([bullet_wait, bullet_spawn])
        self.run(SKAction.repeatForever(bullet_sequence))
        
        background1.position = CGPoint(x: 0, y: self.frame.height / 2)
        background2.position = CGPoint(x: 0, y: self.frame.height * 2)
        background1.zPosition = -5
        background2.zPosition = -5
        
        self.addChild(pluto)
        self.addChild(penguin_character)
        self.addChild(background1)
        self.addChild(delete_node_bot)
        self.addChild(background2)
        self.addChild(delete_node_top)
        self.addChild(scoreLbl)
    }
    
    func spawnBullets()
    {
        let bullet = SKSpriteNode(imageNamed: "SP_Bullet")
        bullet.position = CGPoint(x: penguin_character.position.x + 30, y:penguin_character.position.y + 30)
        bullet.physicsBody = SKPhysicsBody(rectangleOf: bullet.size)
        bullet.physicsBody?.categoryBitMask = PhysicsCatagory.bullet
        bullet.physicsBody?.collisionBitMask = PhysicsCatagory.meteorite | PhysicsCatagory.deletenode_top
        bullet.physicsBody?.contactTestBitMask = PhysicsCatagory.meteorite | PhysicsCatagory.deletenode_top
        let action = SKAction.moveTo(y: self.size.height + 20, duration: 1)
        bullet.run(SKAction.repeatForever(action))
        self.addChild(bullet)
    }
    
    override func didMove(to view: SKView) {
        createScene()
    }
    func gameover_btn()
    {
        gameover = SKSpriteNode(imageNamed: "SP_GameOverText")
        gameover_score = SKSpriteNode(imageNamed: "SP_Score&Best")
        playagain = SKSpriteNode(imageNamed: "SP_BTN_PlayAgain")
        mainmenu = SKSpriteNode(imageNamed: "SP_BTN_MainMenu")
        
        gameover.setScale(0)
        gameover_score.setScale(0)
        playagain.setScale(0)
        mainmenu.setScale(0)
        scoreLbl.setScale(0)
        highscoreLbl.setScale(0)
        
        if(score > highscore)
        {
            highscore = score
        }
        
        gameover.position = CGPoint(x: self.frame.midX, y: 150)
        gameover_score.position = CGPoint(x: self.frame.midX - 50, y: gameover.position.y - 150)
        playagain.position = CGPoint(x: self.frame.midX - playagain.size.width - 80, y: gameover_score.position.y - 100)
        mainmenu.position = CGPoint(x: self.frame.midX + 80, y: gameover_score.position.y - 100)
        
        scoreLbl.position = CGPoint(x: self.frame.midX + 35, y: self.frame.midY + 5)
        scoreLbl.text = "\(score)"
        scoreLbl.fontSize = 45
        scoreLbl.fontColor = SKColor.yellow
        scoreLbl.fontName = "Pixeled"
        scoreLbl.zPosition = 16
        
        highscoreLbl.position = CGPoint(x: self.frame.midX + 35, y: self.frame.midY - 35)
        highscoreLbl.text = "\(highscore)"
        highscoreLbl.fontName = "Pixeld"
        highscoreLbl.zPosition = 5
        highscoreLbl.fontSize = 45
        highscoreLbl.fontColor = SKColor.yellow
        
        gameover.zPosition = 15
        playagain.zPosition = 15
        mainmenu.zPosition = 15
        gameover_score.zPosition = 15
        scoreLbl.zPosition = 15
        highscoreLbl.zPosition = 15
        
        self.addChild(gameover)
        self.addChild(gameover_score)
        self.addChild(playagain)
        self.addChild(mainmenu)
        self.addChild(scoreLbl)
        self.addChild(highscoreLbl)
        
        gameover.run(SKAction.scale(to: 0.5, duration: 0.5))
        gameover_score.run(SKAction.scale(to: 0.5, duration: 0.5))
        playagain.run(SKAction.scale(to: 0.5, duration: 0.5))
        mainmenu.run(SKAction.scale(to: 0.5, duration: 0.5))
        scoreLbl.run(SKAction.scale(to: 1, duration: 0.5))
        highscoreLbl.run(SKAction.scale(to: 1, duration: 0.5))
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        let firstBody = contact.bodyA
        let secondBody = contact.bodyB
        
        if(firstBody.categoryBitMask == PhysicsCatagory.meteorite && secondBody.categoryBitMask == PhysicsCatagory.deletenode_bot)
        {
            firstBody.node?.removeFromParent()
            score -= 1
            scoreLbl.text = "\(score)"
        }
        else if(firstBody.categoryBitMask == PhysicsCatagory.deletenode_bot && secondBody.categoryBitMask == PhysicsCatagory.meteorite)
        {
            secondBody.node?.removeFromParent()
            score -= 1
            scoreLbl.text = "\(score)"
        }
        else if(firstBody.categoryBitMask == PhysicsCatagory.deletenode_top && secondBody.categoryBitMask == PhysicsCatagory.bullet)
        {
            secondBody.node?.removeFromParent()
        }
        else if(firstBody.categoryBitMask == PhysicsCatagory.bullet && secondBody.categoryBitMask == PhysicsCatagory.deletenode_top)
        {
            firstBody.node?.removeFromParent()
        }
        else if(firstBody.categoryBitMask == PhysicsCatagory.meteorite && secondBody.categoryBitMask == PhysicsCatagory.bullet)
        {
            if(hits % 2 == 0)
            {
                firstBody.node?.removeFromParent()
                score += 1
            }
            if(score % 10 == 0 && score != oldten)
            {
                grav -= 0.5
                oldten = score
                self.physicsWorld.gravity = CGVector(dx: 0, dy: grav)
            }
            secondBody.node?.removeFromParent()
            hits += 1
            scoreLbl.text = "\(score)"
            print(score)
        }
        else if(firstBody.categoryBitMask == PhysicsCatagory.bullet && secondBody.categoryBitMask == PhysicsCatagory.meteorite)
        {
            if(hits % 2 == 0)
            {
                secondBody.node?.removeFromParent()
                score += 1
            }
            if(score % 10 == 0 && score != oldten)
            {
                grav -= 0.5
                oldten = score
                self.physicsWorld.gravity = CGVector(dx: 0, dy: grav)
            }
            firstBody.node?.removeFromParent()
            scoreLbl.text = "\(score)"
            hits += 1
            print(score)
        }
        else if(firstBody.categoryBitMask == PhysicsCatagory.character && secondBody.categoryBitMask == PhysicsCatagory.meteorite)
        {
            print("Died")
            self.removeAllActions()
            self.removeAllChildren()
            self.addChild(background1)
            self.addChild(background2)
            self.addChild(pluto)
            if(end == false)
            {
                gameover_btn()
                end = true
                died = true
            }
        }
        else if(firstBody.categoryBitMask == PhysicsCatagory.meteorite && secondBody.categoryBitMask == PhysicsCatagory.character)
        {
            print("Died")
            self.removeAllActions()
            self.removeAllChildren()
            self.addChild(background1)
            self.addChild(background2)
            self.addChild(pluto)
            if(end == false)
            {
                gameover_btn()
                end = true
                died = true
            }
        }
    }
    func meteorites_aka_gummiband()
    {
        let random_meteorite = CGFloat.random(min: 1,max: 7)
        if(random_meteorite <= 1)
        {
            meteorite = SKSpriteNode(imageNamed: "SP_Asteroid0")
        }
        else if(random_meteorite <= 2 && random_meteorite >= 1)
        {
            meteorite = SKSpriteNode(imageNamed: "SP_Asteroid1")
        }
        else if(random_meteorite <= 3 && random_meteorite >= 2)
        {
            meteorite = SKSpriteNode(imageNamed: "SP_Asteroid2")
        }
        else if(random_meteorite <= 4 && random_meteorite >= 4)
        {
            meteorite = SKSpriteNode(imageNamed: "SP_Asteroid3")
        }
        else if(random_meteorite <= 5 && random_meteorite >= 5)
        {
            meteorite = SKSpriteNode(imageNamed: "SP_Asteroid4")
        }
        else if(random_meteorite <= 6 && random_meteorite >= 6)
        {
            meteorite = SKSpriteNode(imageNamed: "SP_Asteroid5")
        }
        else
        {
            meteorite = SKSpriteNode(imageNamed: "SP_Asteroid0")
        }
        
        var randomPos = CGFloat.random(min: 1, max: 8)
        
        while(randomPos == lastxpos)
        {
            randomPos = CGFloat.random(min: 1, max: 7)
        }
        if(randomPos <= 1)
        {
            plusx = 0
            lastxpos = randomPos
        }
        else if(randomPos <= 2 && randomPos >= 1)
        {
            plusx = -50
            lastxpos = randomPos
        }
        else if(randomPos <= 3 && randomPos >= 2)
        {
            plusx = -100
            lastxpos = randomPos
        }
        else if(randomPos <= 4 && randomPos >= 3)
        {
            plusx =  50
            lastxpos = randomPos
        }
        else if(randomPos <= 5 && randomPos >= 4)
        {
            plusx = 150
            lastxpos = randomPos
        }
        else if(randomPos <= 6 && randomPos >= 5)
        {
            plusx = -150
            lastxpos = randomPos
        }
        else if(randomPos <= 7 && randomPos >= 6)
        {
            plusx = 100
            lastxpos = randomPos
        }
        else
        {
            plusx = 200
            lastxpos = randomPos
        }
        meteorite.size = CGSize(width: 100, height: 100)
        meteorite.position = CGPoint(x: self.frame.midX + plusx, y: self.frame.maxY - (meteorite.size.height / 2) + 150)
        print(self.frame.midX+plusx)
        meteorite.physicsBody = SKPhysicsBody(rectangleOf: meteorite.size)
        meteorite.physicsBody?.categoryBitMask = PhysicsCatagory.meteorite
        meteorite.physicsBody?.collisionBitMask = PhysicsCatagory.character | PhysicsCatagory.bullet | PhysicsCatagory.deletenode_bot
        meteorite.physicsBody?.contactTestBitMask = PhysicsCatagory.character | PhysicsCatagory.bullet
        meteorite.zPosition = 5
        meteorite.physicsBody?.isDynamic = true
        meteorite.physicsBody?.affectedByGravity = true
        self.addChild(meteorite)
 
 }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in (touches){
            let location = touch.location(in: self)
            if (died == false){
                if self.contains(location){
                    penguin_character.position.x = location.x
                }
            }
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches{
            let location = touch.location(in: self)
            if (died == true)
            {
                if (playagain.contains(location))
                {
                    print("Load GameScene")
                    let moveScene = GameScene(fileNamed: "GameScene")
                    let transition = SKTransition.fade(withDuration: 0.5)
                    self.scene!.view?.presentScene(moveScene!, transition: transition)
                }
                    
                else if (mainmenu.contains(location))
                {
                    print("Load Main Menu")
                    if let view = self.view{
                        if let scene = MainMenu(fileNamed: "MainMenu") {
                            scene.scaleMode = .aspectFill
                            view.presentScene(scene, transition: SKTransition.fade(withDuration: 1))
                        }
                    }
                    
                }
            }
        }
    }
 
    override func update(_ currentTime: TimeInterval) {
        pluto.position.y -= 0.2
        background1.position = CGPoint(x: background1.position.x, y: background1.position.y - 0.5)
        background2.position = CGPoint(x: background2.position.x, y: background2.position.y - 0.5)
        
        if(background1.position.y <= -background1.size.height + 100)
        {
            background1.position = CGPoint(x: background2.position.x,y: background2.size.height - 333)
        }
        
        if(background2.position.y <= -background2.size.height + 100)
        {
            background2.position = CGPoint(x: background1.position.x, y: background1.size.height - 333)
        }
    }
}
